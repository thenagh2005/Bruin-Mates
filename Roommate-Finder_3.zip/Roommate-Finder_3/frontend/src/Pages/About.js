import React from 'react';

import NavBar from '../NavBar'

function About() {
    return (
        <>
        <NavBar />
        <div>
            <h1>Cool stuff goes here</h1>
        </div>
        </>
    )
}

export default About;